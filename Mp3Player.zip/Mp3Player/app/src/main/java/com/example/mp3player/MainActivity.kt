package com.example.mp3player

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageButton
import android.widget.ListView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var trackList: ListView
    private lateinit var nowPlaying: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var positionText: TextView
    private lateinit var durationText: TextView
    private lateinit var playButton: ImageButton
    private lateinit var shuffleButton: Button
    private lateinit var repeatButton: Button
    private lateinit var adapter: ArrayAdapter<String>

    private val titles = ArrayList<String>()
    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var userSeeking = false

    // Updates the seek bar twice a second while the screen is visible.
    private val ticker = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 500)
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            updatePlayButton()
        }

        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
            updatePlayButton()
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            updatePlayButton()
            updateProgress()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            updateNowPlaying()
            highlightCurrent()
        }

        override fun onTimelineChanged(timeline: Timeline, reason: Int) {
            refreshList()
            if (reason == Player.TIMELINE_CHANGE_REASON_PLAYLIST_CHANGED) {
                persistPlaylist()
            }
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            updateModeButtons()
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            updateModeButtons()
        }

        override fun onPlayerError(error: PlaybackException) {
            Toast.makeText(this@MainActivity, R.string.cannot_play, Toast.LENGTH_SHORT).show()
        }
    }

    private val pickFiles =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) addFiles(uris)
        }

    private val askNotifications =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Keep content clear of the status bar / navigation bar (edge-to-edge on Android 15+).
        val root = findViewById<View>(R.id.root)
        val pad = (16 * resources.displayMetrics.density).toInt()
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(bars.left + pad, bars.top + pad, bars.right + pad, bars.bottom + pad)
            insets
        }

        trackList = findViewById(R.id.trackList)
        nowPlaying = findViewById(R.id.nowPlaying)
        seekBar = findViewById(R.id.seekBar)
        positionText = findViewById(R.id.positionText)
        durationText = findViewById(R.id.durationText)
        playButton = findViewById(R.id.playButton)
        shuffleButton = findViewById(R.id.shuffleButton)
        repeatButton = findViewById(R.id.repeatButton)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_activated_1, titles)
        trackList.adapter = adapter
        trackList.choiceMode = ListView.CHOICE_MODE_SINGLE
        trackList.emptyView = findViewById(R.id.emptyView)
        trackList.setOnItemClickListener { _, _, position, _ -> playIndex(position) }
        trackList.setOnItemLongClickListener { _, _, position, _ ->
            removeTrack(position)
            true
        }

        findViewById<Button>(R.id.addButton).setOnClickListener {
            pickFiles.launch(arrayOf("audio/*"))
        }
        playButton.setOnClickListener { togglePlay() }
        findViewById<ImageButton>(R.id.prevButton).setOnClickListener { controller?.seekToPrevious() }
        findViewById<ImageButton>(R.id.nextButton).setOnClickListener { controller?.seekToNext() }
        shuffleButton.setOnClickListener { toggleShuffle() }
        repeatButton.setOnClickListener { cycleRepeat() }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) positionText.text = formatTime(progress.toLong())
            }

            override fun onStartTrackingTouch(sb: SeekBar) {
                userSeeking = true
            }

            override fun onStopTrackingTouch(sb: SeekBar) {
                userSeeking = false
                controller?.seekTo(sb.progress.toLong())
            }
        })

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        controllerFuture = future
        future.addListener({
            try {
                onControllerReady(future.get())
            } catch (e: Exception) {
                // Released before it finished connecting (activity stopped) - nothing to do.
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onStop() {
        handler.removeCallbacks(ticker)
        controller?.removeListener(playerListener)
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        controller = null
        super.onStop()
    }

    override fun onDestroy() {
        io.shutdown()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- controller

    private fun onControllerReady(c: MediaController) {
        controller = c
        c.addListener(playerListener)
        if (c.mediaItemCount == 0) restorePlaylist(c)
        refreshList()
        updateNowPlaying()
        updatePlayButton()
        updateModeButtons()
        updateProgress()
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    private fun wantsPlayback(c: MediaController): Boolean =
        c.playWhenReady &&
            c.playbackState != Player.STATE_IDLE &&
            c.playbackState != Player.STATE_ENDED

    private fun togglePlay() {
        val c = controller ?: return
        if (c.mediaItemCount == 0) {
            pickFiles.launch(arrayOf("audio/*"))
            return
        }
        if (wantsPlayback(c)) {
            c.pause()
            return
        }
        if (c.playbackState == Player.STATE_IDLE) c.prepare()
        if (c.playbackState == Player.STATE_ENDED) c.seekTo(0, 0L)
        c.play()
    }

    private fun playIndex(index: Int) {
        val c = controller ?: return
        if (c.playbackState == Player.STATE_IDLE) c.prepare()
        c.seekTo(index, 0L)
        c.play()
    }

    private fun removeTrack(index: Int) {
        val c = controller ?: return
        if (index in 0 until c.mediaItemCount) {
            c.removeMediaItem(index)
            Toast.makeText(this, R.string.removed, Toast.LENGTH_SHORT).show()
        }
    }

    private fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    private fun cycleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    // ---------------------------------------------------------------- adding files

    private fun addFiles(uris: List<Uri>) {
        // Keep access to the files after the app restarts.
        for (uri in uris) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (e: Exception) {
                // Some providers don't support persistable grants; playback still works now.
            }
        }

        io.execute {
            val items = uris.map { buildItem(it) }
            runOnUiThread {
                val c = controller ?: return@runOnUiThread
                c.addMediaItems(items)
                if (c.playbackState == Player.STATE_IDLE) c.prepare()
            }
        }
    }

    private fun buildItem(uri: Uri): MediaItem {
        var title: String? = null
        var artist: String? = null
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(this, uri)
            title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
            artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
        } catch (e: Exception) {
            // No readable tags - fall back to the file name below.
        } finally {
            try {
                retriever.release()
            } catch (e: Exception) {
                // ignore
            }
        }
        if (title.isNullOrBlank()) title = displayName(uri)
        return makeItem(uri, title, artist)
    }

    private fun displayName(uri: Uri): String {
        var name: String? = null
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        name = cursor.getString(0)
                    }
                }
        } catch (e: Exception) {
            // ignore
        }
        val raw = name ?: uri.lastPathSegment ?: "Track"
        return raw.substringBeforeLast('.')
    }

    private fun makeItem(uri: Uri, title: String?, artist: String?): MediaItem {
        val metadata = MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist?.takeIf { it.isNotBlank() })
            .build()
        return MediaItem.Builder()
            .setMediaId(uri.toString())
            .setUri(uri)
            .setMediaMetadata(metadata)
            .build()
    }

    // ---------------------------------------------------------------- saving the playlist

    private fun persistPlaylist() {
        val c = controller ?: return
        val array = JSONArray()
        for (i in 0 until c.mediaItemCount) {
            val item = c.getMediaItemAt(i)
            val obj = JSONObject()
            obj.put("uri", item.mediaId)
            obj.put("title", item.mediaMetadata.title?.toString() ?: "")
            obj.put("artist", item.mediaMetadata.artist?.toString() ?: "")
            array.put(obj)
        }
        getSharedPreferences("playlist", MODE_PRIVATE)
            .edit()
            .putString("items", array.toString())
            .apply()
    }

    private fun restorePlaylist(c: MediaController) {
        val json = getSharedPreferences("playlist", MODE_PRIVATE).getString("items", null) ?: return
        try {
            val array = JSONArray(json)
            val items = ArrayList<MediaItem>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                items.add(
                    makeItem(
                        Uri.parse(obj.getString("uri")),
                        obj.optString("title"),
                        obj.optString("artist")
                    )
                )
            }
            if (items.isNotEmpty()) {
                c.setMediaItems(items)
                c.prepare()
            }
        } catch (e: Exception) {
            // Corrupt saved list - start empty.
        }
    }

    // ---------------------------------------------------------------- UI updates

    private fun refreshList() {
        val c = controller
        titles.clear()
        if (c != null) {
            for (i in 0 until c.mediaItemCount) {
                val meta = c.getMediaItemAt(i).mediaMetadata
                val title = meta.title?.toString()?.takeIf { it.isNotBlank() } ?: "Track ${i + 1}"
                val artist = meta.artist?.toString()?.takeIf { it.isNotBlank() }
                titles.add(if (artist == null) title else "$title — $artist")
            }
        }
        adapter.notifyDataSetChanged()
        highlightCurrent()
    }

    private fun highlightCurrent() {
        val c = controller
        if (c == null || c.mediaItemCount == 0) {
            trackList.clearChoices()
        } else {
            trackList.setItemChecked(c.currentMediaItemIndex, true)
        }
    }

    private fun updateNowPlaying() {
        val title = controller?.currentMediaItem?.mediaMetadata?.title?.toString()
        nowPlaying.text =
            if (title.isNullOrBlank()) getString(R.string.nothing_playing) else title
    }

    private fun updatePlayButton() {
        val c = controller ?: return
        playButton.setImageResource(
            if (wantsPlayback(c)) R.drawable.ic_pause else R.drawable.ic_play
        )
    }

    private fun updateModeButtons() {
        val c = controller ?: return
        shuffleButton.text =
            getString(if (c.shuffleModeEnabled) R.string.shuffle_on else R.string.shuffle_off)
        repeatButton.text = getString(
            when (c.repeatMode) {
                Player.REPEAT_MODE_ALL -> R.string.repeat_all
                Player.REPEAT_MODE_ONE -> R.string.repeat_one
                else -> R.string.repeat_off
            }
        )
    }

    private fun updateProgress() {
        val c = controller ?: return
        val duration = c.duration
        if (duration == C.TIME_UNSET || duration < 0) {
            seekBar.max = 0
            durationText.text = formatTime(0)
        } else {
            seekBar.max = duration.toInt()
            durationText.text = formatTime(duration)
        }
        if (!userSeeking) {
            val position = c.currentPosition.coerceAtLeast(0L)
            seekBar.progress = position.toInt()
            positionText.text = formatTime(position)
        }
    }

    private fun formatTime(ms: Long): String {
        val totalSeconds = (ms / 1000).coerceAtLeast(0L)
        return String.format(Locale.getDefault(), "%d:%02d", totalSeconds / 60, totalSeconds % 60)
    }
}
