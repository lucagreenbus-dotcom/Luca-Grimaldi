# MP3 Player (Android)

A small, ad-free MP3 player for Android 8.0+ (API 26).

**Features:** pick any number of audio files from your phone, playlist that survives restarts,
play/pause, previous/next, seek bar, shuffle, repeat (off / all / one), background playback with
notification and lock-screen controls, pauses when headphones are unplugged.
Long-press a track to remove it from the list. Besides MP3 it plays whatever Android can decode
(M4A, OGG, FLAC, WAV…).

Built with Kotlin and AndroidX Media3 (ExoPlayer + MediaSession).

## Get the APK

### Option A – GitHub (no setup on your computer)
1. Create a new GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the **Actions** tab → **Build APK** → wait for the green check (about 3–5 minutes).
   You can also start it by hand with **Run workflow**.
3. Open the finished run and download **mp3player-debug-apk** (a zip containing `app-debug.apk`).

### Option B – Android Studio
1. Install Android Studio, choose **Open**, and select this folder. Let Gradle sync.
2. **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
3. The file is at `app/build/outputs/apk/debug/app-debug.apk`.

### Option C – command line
With JDK 17+ and the Android SDK installed (`ANDROID_HOME` set):

```
./gradlew assembleDebug
```

## Install on your phone
Copy `app-debug.apk` to the phone and open it. Android will ask you to allow installing from that
source (your browser or file manager) the first time. The debug APK is signed with a debug key,
which is fine for personal use; for the Play Store you would build a signed release instead.

## Project layout
- `app/src/main/java/com/example/mp3player/PlaybackService.kt` – owns the player, runs in the background
- `app/src/main/java/com/example/mp3player/MainActivity.kt` – playlist and controls UI
- `app/src/main/res/` – layout, strings, icons
- `app/build.gradle.kts` – app id (`com.example.mp3player`), SDK versions, dependencies

To use your own package name, change `namespace` and `applicationId` in `app/build.gradle.kts`
and move the Kotlin files into a matching folder.
